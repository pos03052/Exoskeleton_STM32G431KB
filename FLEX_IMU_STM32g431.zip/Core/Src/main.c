/* USER CODE BEGIN Header */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "fdcan.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//#include "stdbool.h"
//#include "serial.h"
//#include "arm_math.h"
//#include "string.h"
//#include "stdio.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void setup(void);
void sendSensorDataSerial();
void calcFlex();

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// Sensor data buffers
float buff_angles[2][3] = { 0.0 };  // gyro sensor values
int buff_flex[2][14];    // flex data from Mollisen [Left[14]], Right[14]];
int stretch_btn_l = 0, stretch_btn_r = 0;

extern uint8_t buff_gyro_full[2]; 
extern uint8_t buff_flex_full[4];

int can_send_flag = 0;
int uart_send_flag = 0;


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_FDCAN1_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  
  setup();
  HAL_Delay(10);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    vcp.run(&vcp);
	
    calcFlex();
    if(can_send_flag){ // send CAN frame for testing
      SEND_FRAME(&hcan);
      can_send_flag =0;
    }
	
	//    if(uart_send_flag){
	//      serial_print(&vcp, "123");
	//      uart_send_flag=0;
	//    }
	//    sendSensorDataSerial();
	//	HAL_Delay(40);
	
	/* USER CODE END WHILE */
	
	/* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV6;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enables the Clock Security System
  */
  HAL_RCC_EnableCSS();
}

/* USER CODE BEGIN 4 */
int test= 0;
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
  test=1;
}

void setup(void)
{  
  __disable_irq();
  
  /* USART for Virtual com port */
  vcp.init(&vcp);
  
  if (HAL_FDCAN_Start(hcan.module) != HAL_OK)
  {
	Error_Handler();
  }  
  if (HAL_FDCAN_ActivateNotification(hcan.module, hcan.activeITs, 0) != HAL_OK)
  {
	Error_Handler();
  }  
  if (HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_TX_FIFO_EMPTY|FDCAN_IT_TX_COMPLETE, FDCAN_TX_BUFFER0 | FDCAN_TX_BUFFER1 | FDCAN_TX_BUFFER2) != HAL_OK)
  {	
	Error_Handler();	
  }  
  hcan.txmsg.header.IdType = FDCAN_STANDARD_ID;						// FDCAN_STANDARD_ID, FDCAN_EXTENDED_ID
  hcan.txmsg.header.TxFrameType = FDCAN_DATA_FRAME;					// FDCAN_DATA_FRAME, FDCAN_REMOTE_FRAME(FDCAN High Priority MEssage Storage)
  hcan.txmsg.header.DataLength = FDCAN_DLC_BYTES_8;					// FDCAN_DLC_BYTES_0~64: FDCAN Data Length Code
  hcan.txmsg.header.ErrorStateIndicator = FDCAN_ESI_ACTIVE;			// Transmitting node is error active, FDCAN_ESI_PASSIVE: Transmitting node is error passive
  hcan.txmsg.header.BitRateSwitch = FDCAN_BRS_OFF;					// Tx frame w/ or w/o bit rate switching
  hcan.txmsg.header.FDFormat = FDCAN_CLASSIC_CAN;					// Tx frame classic or FD
  hcan.txmsg.header.TxEventFifoControl = FDCAN_NO_TX_EVENTS;		// store or not store Tx events
  hcan.txmsg.header.MessageMarker = 0;								// message marker copied into Tx Event FIFO element 0 ~ 0xFF
	__enable_irq();		// iar enable interrupt

}

char tx_buffer[200];
void sendSensorDataSerial(){
  // send to serial if data has been received from both imu sensors
  sprintf(tx_buffer,"%d,%d,%d,%d,%d,%d;",  (int)(buff_angles[0][0]*100), (int)(buff_angles[0][1]*100), (int)(buff_angles[1][0]*100), (int)(buff_angles[1][1]*100), stretch_btn_l, stretch_btn_r); // imu1(roll,pitch), imu2(roll,pitch), stretch_l, stretch_r - data is seperated by commas. end of packet is showed by semi-colon
  serial_print(&vcp, tx_buffer);
} 

int rxcount_vcp = 0;
void parse_vcp(SerialHandler *h)
{
  rxcount_vcp++;
  START_IMU();
  uart_send_flag=1;
  
}

int _tick = 0;
void HAL_SYSTICK_Callback(){ // called every 20ms
  
  if(_tick++ > MAX_TICK){
	if(uart_send_flag){
	  sendSensorDataSerial();
	}
    _tick=0;
  }
}

int STRETCH_THRESHOLD_HIGH = 40;
int STRETCH_THRESHOLD_LOW = 35;
void calcFlex(){
  float l_sum = 0.0, r_sum = 0.0;
  
  // Left hand
  if(buff_flex_full[0] && buff_flex_full[1]){
    for (int i = 0; i < 14; i++) {
      l_sum += buff_flex[0][i];
    }
    l_sum /= 14;  // calculate the norm
    
    if (stretch_btn_l == 0) {
      stretch_btn_l = l_sum > STRETCH_THRESHOLD_HIGH ? 1 : 0;
    } else {
      stretch_btn_l = l_sum < STRETCH_THRESHOLD_LOW ? 0 : 1;
    }
    buff_flex_full[0] =0;
    buff_flex_full[1]=0;
  }
  
  // Right hand
  if(buff_flex_full[2] && buff_flex_full[3]){
    for (int i = 0; i < 14; i++) {
      r_sum += buff_flex[1][i];
    }
    r_sum /= 14;  // calculate the norm
    
    // Activate the Schmitt trigger
    if (stretch_btn_r == 0) {
      stretch_btn_r = r_sum > STRETCH_THRESHOLD_HIGH ? 1 : 0;
    } else {
      stretch_btn_r = r_sum < STRETCH_THRESHOLD_LOW ? 0 : 1;
    }
    buff_flex_full[2] =0;
    buff_flex_full[3]=0;
  }
  
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
