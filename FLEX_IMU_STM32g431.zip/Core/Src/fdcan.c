/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    fdcan.c
  * @brief   This file provides code for the configuration
  *          of the FDCAN instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "fdcan.h"

/* USER CODE BEGIN 0 */
#define MSG_SIZE 8 // 8 bytes

extern float buff_angles[2][3];  // gyro sensor values
uint8_t buff_gyro_full[2];             // {gyro_1, gyro_2}


extern int buff_flex[2][14];    // flex data from Mollisen [Left[14]], Right[14]];
uint8_t buff_flex_full[4];  //{Flex_L_1, Flex_L_2, Flex_R_1, Flex_R_2}

extern int stretch_btn_l;
extern int stretch_btn_r;

int rx_buffer_cnt[6]={0};

CAN_HandleTypeDef hcan = {
  &hfdcan1, 
  {0,}, 
  {0,}, 
  FDCAN_TX_BUFFER0,				// FDCAN_TX_BUFFER0, 1, 2
  FDCAN_RX_FIFO0,					// FDCAN_RX_FIFO0, 1
  FDCAN_IT_RX_FIFO0_NEW_MESSAGE,	// FDCANIT_RX_FIFO0_MESSAGE_LOST/FULL/NEW_MESSAGE(New message written to Rx FIFO 0)
};
/* USER CODE END 0 */

FDCAN_HandleTypeDef hfdcan1;

/* FDCAN1 init function */
void MX_FDCAN1_Init(void)
{

  /* USER CODE BEGIN FDCAN1_Init 0 */

  /* USER CODE END FDCAN1_Init 0 */

  /* USER CODE BEGIN FDCAN1_Init 1 */

  /* USER CODE END FDCAN1_Init 1 */
  hfdcan1.Instance = FDCAN1;
  hfdcan1.Init.ClockDivider = FDCAN_CLOCK_DIV1;
  hfdcan1.Init.FrameFormat = FDCAN_FRAME_CLASSIC;
  hfdcan1.Init.Mode = FDCAN_MODE_NORMAL;
  hfdcan1.Init.AutoRetransmission = DISABLE;
  hfdcan1.Init.TransmitPause = DISABLE;
  hfdcan1.Init.ProtocolException = DISABLE;
  hfdcan1.Init.NominalPrescaler = 10;
  hfdcan1.Init.NominalSyncJumpWidth = 1;
  hfdcan1.Init.NominalTimeSeg1 = 14;
  hfdcan1.Init.NominalTimeSeg2 = 2;
  hfdcan1.Init.DataPrescaler = 1;
  hfdcan1.Init.DataSyncJumpWidth = 1;
  hfdcan1.Init.DataTimeSeg1 = 1;
  hfdcan1.Init.DataTimeSeg2 = 1;
  hfdcan1.Init.StdFiltersNbr = 0;
  hfdcan1.Init.ExtFiltersNbr = 0;
  hfdcan1.Init.TxFifoQueueMode = FDCAN_TX_FIFO_OPERATION;
  if (HAL_FDCAN_Init(&hfdcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN FDCAN1_Init 2 */

  /* USER CODE END FDCAN1_Init 2 */

}

void HAL_FDCAN_MspInit(FDCAN_HandleTypeDef* fdcanHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
  if(fdcanHandle->Instance==FDCAN1)
  {
  /* USER CODE BEGIN FDCAN1_MspInit 0 */

  /* USER CODE END FDCAN1_MspInit 0 */

  /** Initializes the peripherals clocks
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_FDCAN;
    PeriphClkInit.FdcanClockSelection = RCC_FDCANCLKSOURCE_PCLK1;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
      Error_Handler();
    }

    /* FDCAN1 clock enable */
    __HAL_RCC_FDCAN_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**FDCAN1 GPIO Configuration
    PA11     ------> FDCAN1_RX
    PA12     ------> FDCAN1_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_FDCAN1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* FDCAN1 interrupt Init */
    HAL_NVIC_SetPriority(FDCAN1_IT0_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(FDCAN1_IT0_IRQn);
  /* USER CODE BEGIN FDCAN1_MspInit 1 */

  /* USER CODE END FDCAN1_MspInit 1 */
  }
}

void HAL_FDCAN_MspDeInit(FDCAN_HandleTypeDef* fdcanHandle)
{

  if(fdcanHandle->Instance==FDCAN1)
  {
  /* USER CODE BEGIN FDCAN1_MspDeInit 0 */

  /* USER CODE END FDCAN1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_FDCAN_CLK_DISABLE();

    /**FDCAN1 GPIO Configuration
    PA11     ------> FDCAN1_RX
    PA12     ------> FDCAN1_TX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_11|GPIO_PIN_12);

    /* FDCAN1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(FDCAN1_IT0_IRQn);
  /* USER CODE BEGIN FDCAN1_MspDeInit 1 */

  /* USER CODE END FDCAN1_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
void SEND_FRAME(CAN_HandleTypeDef *h)
{    
  if (HAL_FDCAN_AddMessageToTxFifoQ(h->module, &h->txmsg.header, h->txmsg.data) != HAL_OK)
  {
	Error_Handler();
  }  
}

void SYNC_FRAME(uint32_t id, int start)
{
  uint8_t data[8];
  
  data[0]=0x18;
  data[1]=0x16;
  data[2]=0x00;
  data[3]=0x00;
  data[4]=start>0 ? 0x04 : 0x00; // if start==1, request sync packets, if 0, stop packets
  data[5]=0x00;
  data[6]=0x00;
  data[7]=0x00;
  
  hcan.txmsg.header.Identifier = id;
  
  memcpy(hcan.txmsg.data,data,MSG_SIZE);  
  SEND_FRAME(&hcan);
}

void START_IMU(void){
  SYNC_FRAME(IMU1_ID,1);
  SYNC_FRAME(IMU2_ID,1);
}

void PARSE_IMU(uint32_t id, uint8_t data[8]){
  float roll, pitch, yaw;
  // Angles are represented in 2's complement
  roll = data[3] & 0x80 ? -(1 + data[2] ^ 0xFF + (data[3] ^ 0xFF) * 256) / 100.0 : (data[2] + (data[3] & 0x7F) * 256) / 100.0;
  pitch = data[5] & 0x80 ? -(1 + data[4] ^ 0xFF + (data[5] ^ 0xFF) * 256) / 100.0 : (data[4] + (data[5] & 0x7F) * 256) / 100.0;
  yaw = data[7] & 0x80 ? -(1 + data[6] ^ 0xFF + (data[7] ^ 0xFF) * 256) / 100.0 : (data[6] + (data[7] & 0x7F) * 256) / 100.0;
  
  
  if (!(id ^ IMU1_ID)) {  // id: 1
    buff_angles[0][0] = roll;
    buff_angles[0][1] = pitch;
    buff_angles[0][2] = yaw;
    buff_gyro_full[0] = 1;
    
  } else if (!(id ^ IMU2_ID)) {  // id: 2
    buff_angles[1][0] = roll;
    buff_angles[1][1] = pitch;
    buff_angles[1][2] = yaw;
    buff_gyro_full[1] = 1;
  }
}

void PARSE_FLEX(uint32_t id, uint8_t data[8]){
  
   if (!(id ^ GLOVE_L1_ID) || !(id ^ GLOVE_R1_ID)) {  // First set of flex messages L[0-7] or R[0-7]
      int hand_idx = !(id ^ 0x7f0) ? 0 : 1;                       // 0 for left, 1 for right
      buff_flex[hand_idx][0] = data[0];
      buff_flex[hand_idx][1] = data[1];
      buff_flex[hand_idx][2] = data[2];
      buff_flex[hand_idx][3] = data[3];
      buff_flex[hand_idx][4] = data[4];
      buff_flex[hand_idx][5] = data[5];
      buff_flex[hand_idx][6] = data[6];
      buff_flex[hand_idx][7] = data[7];

      if (!(id ^ GLOVE_L1_ID)) {
        buff_flex_full[0] = 1;
      } else {
        buff_flex_full[2] = 1;
      }
    } else if (!(id ^ GLOVE_L2_ID) || !(id ^ GLOVE_R2_ID)) {  // Second set of flex messages L[8-13] or R[8-13]
      int hand_idx = !(id ^ 0x7f1) ? 0 : 1;                         // 0 for left, 1 for right
      buff_flex[hand_idx][8] = data[0];
      buff_flex[hand_idx][9] = data[1];
      buff_flex[hand_idx][10] = data[2];
      buff_flex[hand_idx][11] = data[3];
      buff_flex[hand_idx][12] = data[4];
      buff_flex[hand_idx][13] = data[5];

      if (!(id ^ GLOVE_L2_ID)) buff_flex_full[1] = 1;
      else buff_flex_full[3] = 1;
    }
}

void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
{
  if(__HAL_FDCAN_GET_FLAG(hfdcan, FDCAN_FLAG_RX_FIFO0_MESSAGE_LOST)){
	__HAL_FDCAN_CLEAR_FLAG(hfdcan, FDCAN_FLAG_RX_FIFO0_MESSAGE_LOST);
  } 
  if ((hfdcan->Instance == hcan.module->Instance) && ((RxFifo0ITs & hcan.activeITs) != 0))
  {
	if (HAL_FDCAN_GetRxMessage(hcan.module, hcan.rxloc, &hcan.rxmsg.header, hcan.rxmsg.data) != HAL_OK)
	{	    
	  Error_Handler();
	}else{
          uint32_t id = hcan.rxmsg.header.Identifier;
          
          //Id: hcan.rxmsg.header.Identifier 
          // data:  hcan.rxmsg.data
          
          if(id==IMU1_ID || id == IMU2_ID){
              PARSE_IMU(id, hcan.rxmsg.data);
          }
          else if(id == GLOVE_L1_ID || id == GLOVE_R1_ID || id == GLOVE_L2_ID || id == GLOVE_R2_ID){
              PARSE_FLEX(id, hcan.rxmsg.data);
          }
          
          
          if(id == IMU1_ID) rx_buffer_cnt[0]++;
          else if(id == IMU2_ID) rx_buffer_cnt[1]++;
          else if(id == GLOVE_L1_ID) rx_buffer_cnt[2]++;
          else if(id == GLOVE_L2_ID) rx_buffer_cnt[3]++;
          else if(id == GLOVE_R1_ID) rx_buffer_cnt[4]++;
          else if(id == GLOVE_R2_ID) rx_buffer_cnt[5]++;
	}
	if(HAL_FDCAN_GetRxFifoFillLevel(&hfdcan1, FDCAN_RX_FIFO0) >= 2){	// Fifo fill level ���� �� ������ ���
	  while(HAL_FDCAN_GetRxMessage(hcan.module, hcan.rxloc, &hcan.rxmsg.header, hcan.rxmsg.data) != HAL_OK);
	}
  }
}


/* USER CODE END 1 */
